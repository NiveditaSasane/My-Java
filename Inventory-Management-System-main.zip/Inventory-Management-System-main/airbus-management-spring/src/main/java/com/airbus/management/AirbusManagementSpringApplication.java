package com.airbus.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirbusManagementSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirbusManagementSpringApplication.class, args);
	}

}
