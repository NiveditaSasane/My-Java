export class LoginFormClass{
    username:string;
	password:string;

    constructor(){
        this.username="";
        this.password="";
    }
}